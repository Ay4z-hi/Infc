"use client"

import { useState } from "react"
import { ImageIcon, Download, Maximize2, Copy, Check, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface ImageGeneratorProps {
  imageUrl: string
  prompt: string
  onImageClick?: () => void
}

export function ImageGenerator({ imageUrl, prompt, onImageClick }: ImageGeneratorProps) {
  const [imageLoaded, setImageLoaded] = useState(false)
  const [imageError, setImageError] = useState(false)
  const [copied, setCopied] = useState(false)
  const [expanded, setExpanded] = useState(false)

  const downloadImage = async () => {
    try {
      // Create a proper download using fetch and blob
      const response = await fetch(imageUrl, {
        mode: "cors",
        headers: {
          Accept: "image/*",
        },
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `inf-c-generated-${Date.now()}.png`
      a.style.display = "none"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Failed to download image:", error)
      // Fallback: open in new tab
      window.open(imageUrl, "_blank")
    }
  }

  const copyPrompt = async () => {
    try {
      await navigator.clipboard.writeText(prompt)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error("Failed to copy prompt:", error)
    }
  }

  const copyImageUrl = async () => {
    try {
      await navigator.clipboard.writeText(imageUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error("Failed to copy image URL:", error)
    }
  }

  const openInNewTab = () => {
    window.open(imageUrl, "_blank")
  }

  if (expanded) {
    return (
      <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
        <div className="relative max-w-4xl max-h-full">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setExpanded(false)}
            className="absolute top-2 right-2 z-10 bg-black/50 text-white hover:bg-black/70"
          >
            ×
          </Button>
          <img
            src={imageUrl || "/placeholder.svg"}
            alt={prompt}
            className="max-w-full max-h-full object-contain rounded-lg"
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageError(true)}
            crossOrigin="anonymous"
          />
        </div>
      </div>
    )
  }

  return (
    <Card className="mt-3 overflow-hidden bg-gradient-to-br from-red-50 to-orange-50 border-red-200">
      {/* Header */}
      <div className="flex items-center justify-between p-3 bg-gradient-to-r from-red-100 to-orange-100 border-b border-red-200">
        <div className="flex items-center gap-2">
          <ImageIcon className="w-4 h-4 text-red-600" />
          <span className="text-sm font-medium text-red-800">Generated Image</span>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={() => setExpanded(true)} title="View full size">
            <Maximize2 className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={openInNewTab} title="Open in new tab">
            <ExternalLink className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={downloadImage} title="Download image">
            <Download className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={copyImageUrl} title="Copy image URL">
            {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>
      </div>

      {/* Image */}
      <div className="relative">
        {!imageLoaded && !imageError && (
          <div className="aspect-square bg-gradient-to-br from-red-100 to-orange-100 flex items-center justify-center">
            <div className="flex flex-col items-center gap-2">
              <div className="w-8 h-8 border-2 border-red-500 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-sm text-red-600">Generating image...</span>
            </div>
          </div>
        )}

        {imageError && (
          <div className="aspect-square bg-gradient-to-br from-red-100 to-orange-100 flex items-center justify-center">
            <div className="text-center">
              <ImageIcon className="w-12 h-12 text-red-400 mx-auto mb-2" />
              <span className="text-sm text-red-600">Failed to load image</span>
              <Button variant="outline" size="sm" onClick={openInNewTab} className="mt-2">
                Try opening in new tab
              </Button>
            </div>
          </div>
        )}

        <img
          src={imageUrl || "/placeholder.svg"}
          alt={prompt}
          className={`w-full max-w-md mx-auto rounded-lg cursor-pointer transition-opacity ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
          onLoad={() => setImageLoaded(true)}
          onError={() => setImageError(true)}
          onClick={() => setExpanded(true)}
          crossOrigin="anonymous"
        />
      </div>

      {/* Prompt */}
      <div className="p-3 border-t border-red-200">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <p className="text-xs text-red-600 mb-1">Prompt:</p>
            <p className="text-sm text-red-800 break-words">{prompt}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={copyPrompt} title="Copy prompt">
            {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>
      </div>
    </Card>
  )
}
