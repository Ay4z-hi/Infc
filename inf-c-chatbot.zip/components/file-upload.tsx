"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, ImageIcon, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface FileUploadProps {
  onFileSelect: (file: File, type: "image" | "document") => void
  disabled?: boolean
}

export function FileUpload({ onFileSelect, disabled }: FileUploadProps) {
  const [dragActive, setDragActive] = useState(false)
  const imageInputRef = useRef<HTMLInputElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0]
      const type = file.type.startsWith("image/") ? "image" : "document"
      onFileSelect(file, type)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: "image" | "document") => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0], type)
    }
  }

  return (
    <div className="flex gap-2">
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        onChange={(e) => handleFileChange(e, "image")}
        className="hidden"
        disabled={disabled}
      />
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.doc,.docx,.txt,.md"
        onChange={(e) => handleFileChange(e, "document")}
        className="hidden"
        disabled={disabled}
      />

      <Button
        variant="ghost"
        size="sm"
        onClick={() => imageInputRef.current?.click()}
        disabled={disabled}
        className="p-2"
      >
        <ImageIcon className="w-4 h-4" />
      </Button>

      <Button
        variant="ghost"
        size="sm"
        onClick={() => fileInputRef.current?.click()}
        disabled={disabled}
        className="p-2"
      >
        <FileText className="w-4 h-4" />
      </Button>

      <div
        className={`relative ${dragActive ? "opacity-100" : "opacity-0 pointer-events-none"} transition-opacity`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <Card className="absolute inset-0 border-2 border-dashed border-primary bg-primary/10 flex items-center justify-center">
          <div className="text-center">
            <Upload className="w-8 h-8 mx-auto mb-2 text-primary" />
            <p className="text-sm text-primary">Drop files here</p>
          </div>
        </Card>
      </div>
    </div>
  )
}
