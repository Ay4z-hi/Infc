"use client"
import { X, Palette, Monitor, Sun, Moon, Volume2, VolumeX, Zap, User, ImageIcon, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"

interface SettingsModalProps {
  isOpen: boolean
  onClose: () => void
  theme: string
  onThemeChange: (theme: string) => void
  fontSize: number
  onFontSizeChange: (size: number) => void
  soundEnabled: boolean
  onSoundToggle: (enabled: boolean) => void
  animationsEnabled: boolean
  onAnimationsToggle: (enabled: boolean) => void
}

export function SettingsModal({
  isOpen,
  onClose,
  theme,
  onThemeChange,
  fontSize,
  onFontSizeChange,
  soundEnabled,
  onSoundToggle,
  animationsEnabled,
  onAnimationsToggle,
}: SettingsModalProps) {
  if (!isOpen) return null

  const themes = [
    { value: "fiery", label: "Infernal", icon: Palette },
    { value: "light", label: "Light Flame", icon: Sun },
    { value: "dark", label: "Dark Ember", icon: Moon },
    { value: "auto", label: "System", icon: Monitor },
    { value: "purple", label: "Mystic Fire", icon: Palette },
    { value: "blue", label: "Azure Flame", icon: Palette },
    { value: "green", label: "Emerald Fire", icon: Palette },
  ]

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto bg-gradient-to-br from-red-50 to-orange-50 dark:from-gray-900 dark:to-gray-800 border-red-200">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-xl font-semibold text-red-800 dark:text-red-200">Settings</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Theme Selection */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium flex items-center gap-2 text-red-700 dark:text-red-300">
              <Palette className="w-4 h-4" />
              Theme
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {themes.map((themeOption) => {
                const Icon = themeOption.icon
                return (
                  <Button
                    key={themeOption.value}
                    variant={theme === themeOption.value ? "default" : "outline"}
                    size="sm"
                    onClick={() => onThemeChange(themeOption.value)}
                    className="justify-start"
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {themeOption.label}
                  </Button>
                )
              })}
            </div>
          </div>

          {/* Font Size */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-red-700 dark:text-red-300">Font Size</h3>
            <div className="space-y-2">
              <Slider
                value={[fontSize]}
                onValueChange={(value) => onFontSizeChange(value[0])}
                max={20}
                min={12}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-red-600 dark:text-red-400">
                <span>Small (12px)</span>
                <span>Current: {fontSize}px</span>
                <span>Large (20px)</span>
              </div>
            </div>
          </div>

          {/* Streaming Speed */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium flex items-center gap-2 text-red-700 dark:text-red-300">
              <Clock className="w-4 h-4" />
              Typing Speed
            </h3>
            <div className="space-y-2">
              <Slider
                value={[100 - (30 - 10)]} // Convert speed to slider value
                onValueChange={(value) => {
                  // Convert slider value back to speed (10-50ms)
                  const speed = 60 - value[0]
                  // Update streaming speed in parent component would need to be passed as prop
                }}
                max={90}
                min={10}
                step={5}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-red-600 dark:text-red-400">
                <span>Slow</span>
                <span>ChatGPT Style</span>
                <span>Fast</span>
              </div>
            </div>
          </div>

          {/* Sound Settings */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              <span className="text-sm font-medium">Sound Effects</span>
            </div>
            <Switch checked={soundEnabled} onCheckedChange={onSoundToggle} />
          </div>

          {/* Animations */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              <span className="text-sm font-medium">Animations</span>
            </div>
            <Switch checked={animationsEnabled} onCheckedChange={onAnimationsToggle} />
          </div>

          {/* AI Models */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-red-700 dark:text-red-300">AI Models</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm">Chat Model</span>
                <span className="text-xs text-red-600 bg-red-100 px-2 py-1 rounded">DeepSeek v3</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm flex items-center gap-1">
                  <ImageIcon className="w-3 h-3" />
                  Image Model
                </span>
                <span className="text-xs text-red-600 bg-red-100 px-2 py-1 rounded">Pollinations AI</span>
              </div>
            </div>
          </div>

          {/* User Preferences */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium flex items-center gap-2 text-red-700 dark:text-red-300">
              <User className="w-4 h-4" />
              Preferences
            </h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm">Auto-scroll to new messages</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Show typing indicators</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Send with Enter key</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">ChatGPT-style streaming</span>
                <Switch defaultChecked />
              </div>
            </div>
          </div>

          {/* Image Generation Help */}
          <div className="space-y-2 p-3 bg-red-100 dark:bg-red-900/20 rounded-lg">
            <h4 className="text-sm font-medium text-red-800 dark:text-red-200 flex items-center gap-2">
              <ImageIcon className="w-4 h-4" />
              Image Generation
            </h4>
            <p className="text-xs text-red-700 dark:text-red-300">
              Start your message with <code className="bg-red-200 dark:bg-red-800 px-1 rounded">:ig:</code> followed by
              your image description.
            </p>
            <p className="text-xs text-red-600 dark:text-red-400">
              Example:{" "}
              <code className="bg-red-200 dark:bg-red-800 px-1 rounded">:ig: a dragon in a fantasy landscape</code>
            </p>
            <p className="text-xs text-red-500 dark:text-red-500">Powered by Pollinations AI with FLUX model</p>
          </div>

          {/* About */}
          <div className="pt-4 border-t border-red-200 dark:border-red-800">
            <div className="text-center space-y-1">
              <p className="text-sm font-medium text-red-800 dark:text-red-200">Inf.C v2.0</p>
              <p className="text-xs text-red-600 dark:text-red-400">Created by U.I.D. (United Infernal Dominions)</p>
              <p className="text-xs text-red-500 dark:text-red-500">Developed by ay4z</p>
              <div className="text-xs text-red-400 dark:text-red-600 mt-2">
                <p>President: ay4z (Safwan Ayaz)</p>
                <p>Vice Presidents: a_ravnn (S.M. Shayan Sadid), User 39430</p>
              </div>
              <p className="text-xs text-red-300 dark:text-red-700 mt-2">
                ✨ Now with ChatGPT-style streaming & enhanced AI image generation
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
