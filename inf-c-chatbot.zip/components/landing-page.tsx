"use client"

import { useState, useEffect } from "react"
import { Bot, Zap, Shield, Globe, Users, Code, ImageIcon, Mic, FileText, ArrowRight, Star, Flame } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface LandingPageProps {
  onEnterChat: () => void
}

export function LandingPage({ onEnterChat }: LandingPageProps) {
  const [currentFeature, setCurrentFeature] = useState(0)

  const features = [
    {
      icon: Bot,
      title: "Advanced AI Assistant",
      description: "Powered by cutting-edge language models for intelligent conversations",
    },
    {
      icon: ImageIcon,
      title: "AI Image Generation",
      description: "Create stunning visuals with state-of-the-art image generation",
    },
    {
      icon: Mic,
      title: "Voice Integration",
      description: "Speak naturally with voice-to-text transcription",
    },
    {
      icon: Code,
      title: "Code Assistant",
      description: "Get help with programming, debugging, and technical tasks",
    },
  ]

  const stats = [
    { label: "AI Models", value: "10+" },
    { label: "Languages", value: "50+" },
    { label: "Beta Users", value: "1K+" },
    { label: "Uptime", value: "99.9%" },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [features.length])

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-red-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-red-800">Inf.C</h1>
                <p className="text-xs text-red-600">by U.I.D.</p>
              </div>
            </div>
            <Button
              onClick={onEnterChat}
              className="bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white px-6 py-2 rounded-full"
            >
              Try Beta
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-12 sm:py-20 lg:py-32">
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 to-orange-500/10" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl flex items-center justify-center animate-pulse">
                  <Flame className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
                </div>
                <div className="absolute -top-2 -right-2 bg-yellow-400 text-yellow-900 text-xs font-bold px-2 py-1 rounded-full">
                  BETA
                </div>
              </div>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-gray-900 mb-6">
              Meet{" "}
              <span className="bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">Inf.C</span>
            </h1>
            <p className="text-lg sm:text-xl lg:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              The next-generation AI assistant powered by advanced Large Language Models, created by{" "}
              <span className="font-semibold text-red-600">United Infernal Dominions</span>
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button
                onClick={onEnterChat}
                size="lg"
                className="bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white px-8 py-4 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300 w-full sm:w-auto"
              >
                <Bot className="w-5 h-5 mr-2" />
                Start Chatting
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-red-300 text-red-700 hover:bg-red-50 px-8 py-4 rounded-full text-lg font-semibold w-full sm:w-auto"
              >
                <FileText className="w-5 h-5 mr-2" />
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-2xl sm:text-3xl lg:text-4xl font-bold text-red-600 mb-2">{stat.value}</div>
                <div className="text-sm sm:text-base text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Powered by Advanced{" "}
              <span className="bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">LLMs</span>
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
              Experience the future of AI conversation with our cutting-edge Large Language Models
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="space-y-6">
              {features.map((feature, index) => {
                const Icon = feature.icon
                return (
                  <Card
                    key={index}
                    className={`transition-all duration-300 cursor-pointer ${
                      currentFeature === index
                        ? "bg-gradient-to-r from-red-50 to-orange-50 border-red-300 shadow-lg"
                        : "hover:shadow-md"
                    }`}
                    onClick={() => setCurrentFeature(index)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div
                          className={`p-3 rounded-lg ${
                            currentFeature === index
                              ? "bg-gradient-to-r from-red-500 to-orange-500 text-white"
                              : "bg-gray-100 text-gray-600"
                          }`}
                        >
                          <Icon className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                          <p className="text-gray-600">{feature.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            <div className="relative">
              <div className="bg-gradient-to-br from-red-100 to-orange-100 rounded-2xl p-8 shadow-xl">
                <div className="bg-white rounded-xl p-6 shadow-lg">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Inf.C</div>
                      <div className="text-xs text-gray-500">AI Assistant</div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-gray-50 rounded-lg p-3 text-sm">
                      Hello! I'm Inf.C, your advanced AI assistant. I can help you with:
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs">Code</span>
                      <span className="bg-orange-100 text-orange-700 px-2 py-1 rounded-full text-xs">Images</span>
                      <span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs">Voice</span>
                      <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">Files</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About LLMs Section */}
      <section className="py-16 sm:py-24 bg-gradient-to-r from-red-50 to-orange-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              What are{" "}
              <span className="bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">
                Large Language Models?
              </span>
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-red-500" />
                  <span>Neural Networks</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  LLMs are massive neural networks trained on vast amounts of text data, enabling them to understand and
                  generate human-like responses across countless topics.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Globe className="w-5 h-5 text-orange-500" />
                  <span>Global Knowledge</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  These models have been trained on diverse internet content, books, and academic papers, giving them
                  broad knowledge across multiple domains and languages.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-yellow-500" />
                  <span>Safe & Reliable</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Modern LLMs incorporate safety measures and alignment techniques to provide helpful, harmless, and
                  honest responses while respecting user privacy.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* About U.I.D. Section */}
      <section className="py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              About{" "}
              <span className="bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">U.I.D.</span>
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
              United Infernal Dominions - Pioneering the future of AI technology
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <Card className="bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Users className="w-6 h-6 text-red-500" />
                    <h3 className="text-xl font-semibold text-gray-900">Our Leadership</h3>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-orange-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold text-sm">P</span>
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">ay4z (Safwan Ayaz)</div>
                        <div className="text-sm text-gray-600">President & Lead Developer</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-yellow-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold text-sm">VP</span>
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">a_ravnn (S.M. Shayan Sadid)</div>
                        <div className="text-sm text-gray-600">Vice President</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-red-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold text-sm">VP</span>
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">User 39430</div>
                        <div className="text-sm text-gray-600">Vice President</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Our Mission</h3>
                  <p className="text-gray-600 mb-4">
                    To democratize access to advanced AI technology and create intelligent systems that enhance human
                    capabilities while maintaining ethical standards and user privacy.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm">Innovation</span>
                    <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm">Ethics</span>
                    <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm">Accessibility</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="relative">
              <div className="bg-gradient-to-br from-gray-900 to-red-900 rounded-2xl p-8 text-white shadow-2xl">
                <div className="absolute top-4 right-4">
                  <Star className="w-6 h-6 text-yellow-400" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Why Choose Inf.C?</h3>
                <ul className="space-y-3">
                  <li className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                    <span>State-of-the-art AI models</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
                    <span>Multi-modal capabilities</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                    <span>Privacy-focused design</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>Continuous improvement</span>
                  </li>
                </ul>
                <Button onClick={onEnterChat} className="mt-6 bg-white text-gray-900 hover:bg-gray-100 w-full">
                  Experience Inf.C Now
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24 bg-gradient-to-r from-red-500 to-orange-500">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Ready to Experience the Future?
          </h2>
          <p className="text-lg sm:text-xl text-red-100 mb-8 max-w-2xl mx-auto">
            Join thousands of users already exploring the capabilities of advanced AI with Inf.C
          </p>
          <Button
            onClick={onEnterChat}
            size="lg"
            className="bg-white text-red-600 hover:bg-gray-100 px-8 py-4 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <Bot className="w-5 h-5 mr-2" />
            Start Your AI Journey
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div>
                  <div className="font-bold">Inf.C</div>
                  <div className="text-xs text-gray-400">by U.I.D.</div>
                </div>
              </div>
              <p className="text-gray-400 text-sm">
                Advanced AI assistant powered by cutting-edge Large Language Models.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Features</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>AI Chat Assistant</li>
                <li>Image Generation</li>
                <li>Voice Integration</li>
                <li>Code Assistance</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">U.I.D.</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>United Infernal Dominions</li>
                <li>AI Research & Development</li>
                <li>Ethical AI Solutions</li>
                <li>Open Source Initiatives</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 United Infernal Dominions. All rights reserved.</p>
            <p className="mt-2">Developed with ❤️ by the U.I.D. team</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
