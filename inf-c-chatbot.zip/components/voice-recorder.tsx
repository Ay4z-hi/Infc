"use client"

import { useState, useRef, useEffect } from "react"
import { Mic, Square, Play, Pause, Type, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface VoiceRecorderProps {
  onRecordingComplete: (audioBlob: Blob, transcript?: string) => void
  onTranscriptOnly?: (transcript: string) => void
  disabled?: boolean
}

// Define SpeechRecognition and SpeechRecognitionEvent interfaces
declare global {
  interface Window {
    SpeechRecognition: any
    webkitSpeechRecognition: any
  }

  interface SpeechRecognition extends EventTarget {
    continuous: boolean
    interimResults: boolean
    lang: string
    onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null
    onerror: ((this: SpeechRecognition, ev: SpeechRecognitionErrorEvent) => any) | null
    onend: ((this: SpeechRecognition, ev: Event) => any) | null
    start(): void
    stop(): void
  }

  interface SpeechRecognitionEvent extends Event {
    results: SpeechRecognitionResultList
    resultIndex: number
  }

  interface SpeechRecognitionResultList extends Array<SpeechRecognitionResult> {}

  interface SpeechRecognitionResult extends Array<SpeechRecognitionAlternative> {
    isFinal: boolean
  }

  interface SpeechRecognitionAlternative {
    transcript: string
    confidence: number
  }

  interface SpeechRecognitionErrorEvent extends Event {
    error: SpeechRecognitionError
  }

  type SpeechRecognitionError =
    | "no-speech"
    | "aborted"
    | "audio-capture"
    | "network"
    | "not-allowed"
    | "service-not-allowed"
    | "bad-grammar"
    | "language-not-supported"
}

export function VoiceRecorder({ onRecordingComplete, onTranscriptOnly, disabled }: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [transcript, setTranscript] = useState<string>("")
  const [isTranscribing, setIsTranscribing] = useState(false)
  const [transcriptMode, setTranscriptMode] = useState(false) // Text-only mode
  const [speechSupported, setSpeechSupported] = useState(false)

  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  useEffect(() => {
    // Check if speech recognition is supported
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (SpeechRecognition) {
      setSpeechSupported(true)
      const recognition = new SpeechRecognition()
      recognition.continuous = true
      recognition.interimResults = true
      recognition.lang = "en-US"

      recognition.onresult = (event) => {
        let finalTranscript = ""
        let interimTranscript = ""

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript
          if (event.results[i].isFinal) {
            finalTranscript += transcript
          } else {
            interimTranscript += transcript
          }
        }

        setTranscript(finalTranscript + interimTranscript)
      }

      recognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error)
        setIsTranscribing(false)
      }

      recognition.onend = () => {
        setIsTranscribing(false)
      }

      recognitionRef.current = recognition
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
      if (audioUrl) URL.revokeObjectURL(audioUrl)
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [audioUrl])

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      const chunks: BlobPart[] = []

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunks.push(e.data)
        }
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: "audio/wav" })
        if (!transcriptMode) {
          setAudioBlob(blob)
          const url = URL.createObjectURL(blob)
          setAudioUrl(url)
        }
        stream.getTracks().forEach((track) => track.stop())
      }

      mediaRecorderRef.current = mediaRecorder
      mediaRecorder.start()
      setIsRecording(true)
      setRecordingTime(0)
      setTranscript("")

      // Start speech recognition if supported
      if (speechSupported && recognitionRef.current) {
        setIsTranscribing(true)
        recognitionRef.current.start()
      }

      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)
    } catch (error) {
      console.error("Error accessing microphone:", error)
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
      if (timerRef.current) {
        clearInterval(timerRef.current)
        timerRef.current = null
      }
    }

    // Stop speech recognition
    if (recognitionRef.current && isTranscribing) {
      recognitionRef.current.stop()
    }

    // If in transcript mode, send text immediately
    if (transcriptMode && transcript.trim()) {
      setTimeout(() => {
        onTranscriptOnly?.(transcript.trim())
        setTranscript("")
        setRecordingTime(0)
      }, 500) // Small delay to ensure recognition is complete
    }
  }

  const playRecording = () => {
    if (audioUrl && audioRef.current) {
      audioRef.current.play()
      setIsPlaying(true)
    }
  }

  const pauseRecording = () => {
    if (audioRef.current) {
      audioRef.current.pause()
      setIsPlaying(false)
    }
  }

  const sendRecording = () => {
    if (transcriptMode && transcript.trim()) {
      onTranscriptOnly?.(transcript.trim())
    } else if (audioBlob) {
      onRecordingComplete(audioBlob, transcript.trim() || undefined)
    }

    // Reset state
    setAudioBlob(null)
    setAudioUrl(null)
    setTranscript("")
    setRecordingTime(0)
  }

  const cancelRecording = () => {
    setAudioBlob(null)
    setAudioUrl(null)
    setTranscript("")
    setRecordingTime(0)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  // Show recording preview (audio + transcript or transcript only)
  if (audioBlob || (transcriptMode && transcript)) {
    return (
      <Card className="p-4 space-y-3 max-w-md">
        {/* Mode toggle */}
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium">Recording Mode:</span>
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4" />
            <Switch checked={transcriptMode} onCheckedChange={setTranscriptMode} disabled={isRecording} />
            <Type className="w-4 h-4" />
          </div>
        </div>

        {/* Audio player (only if not in transcript mode) */}
        {!transcriptMode && audioBlob && (
          <div className="flex items-center gap-3">
            <audio ref={audioRef} src={audioUrl || undefined} onEnded={() => setIsPlaying(false)} />
            <Button variant="ghost" size="sm" onClick={isPlaying ? pauseRecording : playRecording} className="p-2">
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <span className="text-sm">{formatTime(recordingTime)}</span>
          </div>
        )}

        {/* Transcript display */}
        {transcript && (
          <div className="space-y-2">
            <div className="text-sm font-medium flex items-center gap-2">
              <Type className="w-4 h-4" />
              Transcript:
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg text-sm max-h-32 overflow-y-auto">
              {transcript || "Transcribing..."}
            </div>
          </div>
        )}

        {/* Action buttons */}
        <div className="flex gap-2">
          <Button size="sm" onClick={sendRecording} disabled={!transcript.trim() && !audioBlob} className="flex-1">
            Send {transcriptMode ? "Text" : "Recording"}
          </Button>
          <Button variant="ghost" size="sm" onClick={cancelRecording}>
            Cancel
          </Button>
        </div>
      </Card>
    )
  }

  return (
    <div className="flex items-center gap-2">
      {/* Recording indicator */}
      {isRecording && (
        <Card className="px-3 py-1 flex items-center gap-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          <span className="text-sm">{formatTime(recordingTime)}</span>
          {isTranscribing && (
            <div className="flex items-center gap-1">
              <Type className="w-3 h-3 text-blue-500" />
              <span className="text-xs text-blue-500">Transcribing...</span>
            </div>
          )}
        </Card>
      )}

      {/* Live transcript during recording */}
      {isRecording && transcript && (
        <Card className="px-3 py-2 max-w-xs">
          <div className="text-xs text-gray-600 dark:text-gray-400 truncate">"{transcript}"</div>
        </Card>
      )}

      {/* Mode toggle when not recording */}
      {!isRecording && speechSupported && (
        <div className="flex items-center gap-1">
          <Button
            variant={transcriptMode ? "default" : "ghost"}
            size="sm"
            onClick={() => setTranscriptMode(!transcriptMode)}
            className="p-1"
            title={transcriptMode ? "Text-only mode" : "Audio + Text mode"}
          >
            <Type className="w-3 h-3" />
          </Button>
        </div>
      )}

      {/* Record button */}
      <Button
        variant="ghost"
        size="sm"
        onClick={isRecording ? stopRecording : startRecording}
        disabled={disabled}
        className={`p-2 ${isRecording ? "text-red-500" : ""}`}
        title={transcriptMode ? "Record voice to text" : "Record voice message"}
      >
        {isRecording ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
      </Button>

      {/* Speech support indicator */}
      {!speechSupported && (
        <span className="text-xs text-gray-400" title="Speech recognition not supported">
          No STT
        </span>
      )}
    </div>
  )
}
