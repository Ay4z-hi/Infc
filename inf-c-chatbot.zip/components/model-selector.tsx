"use client"
import { Bot, Brain, Zap, Mic, MicOff, Volume2, VolumeX, ImageIcon, Settings2, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { AI_MODELS, type ChatSettings } from "@/types/models"

interface ModelSelectorProps {
  settings: ChatSettings
  onSettingsChange: (settings: ChatSettings) => void
  isOpen: boolean
  onToggle: () => void
}

export function ModelSelector({ settings, onSettingsChange, isOpen, onToggle }: ModelSelectorProps) {
  const currentModel = AI_MODELS.find((m) => m.id === settings.model) || AI_MODELS[0]

  const updateSetting = <K extends keyof ChatSettings>(key: K, value: ChatSettings[K]) => {
    onSettingsChange({ ...settings, [key]: value })
  }

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case "assistant":
        return <Bot className="w-4 h-4" />
      case "rp":
        return <Zap className="w-4 h-4" />
      case "developer":
        return <Brain className="w-4 h-4" />
      default:
        return <Bot className="w-4 h-4" />
    }
  }

  const getModeDescription = (mode: string) => {
    switch (mode) {
      case "assistant":
        return "Helpful, informative responses"
      case "rp":
        return "Creative roleplay and storytelling"
      case "developer":
        return "Technical programming assistance"
      default:
        return "General assistance"
    }
  }

  if (!isOpen) {
    return (
      <Button
        variant="outline"
        size="sm"
        onClick={onToggle}
        className="flex items-center gap-2 border-red-200 text-red-700 hover:bg-red-50"
      >
        <Settings2 className="w-4 h-4" />
        <span className="hidden sm:inline">{currentModel.name}</span>
        <ChevronDown className="w-3 h-3" />
      </Button>
    )
  }

  return (
    <Card className="absolute top-full right-0 mt-2 w-80 sm:w-96 z-50 bg-white shadow-lg border-red-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg text-red-800">AI Settings</CardTitle>
          <Button variant="ghost" size="sm" onClick={onToggle}>
            ×
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Model Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-red-700">AI Model</label>
          <Select value={settings.model} onValueChange={(value) => updateSetting("model", value)}>
            <SelectTrigger className="border-red-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {AI_MODELS.map((model) => (
                <SelectItem key={model.id} value={model.id}>
                  <div className="flex items-center justify-between w-full">
                    <div>
                      <div className="font-medium">{model.name}</div>
                      <div className="text-xs text-gray-500">{model.description}</div>
                    </div>
                    {model.free && (
                      <Badge variant="secondary" className="ml-2">
                        Free
                      </Badge>
                    )}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex flex-wrap gap-1">
            {currentModel.capabilities.map((cap) => (
              <Badge key={cap} variant="outline" className="text-xs">
                {cap}
              </Badge>
            ))}
          </div>
        </div>

        {/* Mode Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-red-700">Assistant Mode</label>
          <Select value={settings.mode} onValueChange={(value: any) => updateSetting("mode", value)}>
            <SelectTrigger className="border-red-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="assistant">
                <div className="flex items-center gap-2">
                  <Bot className="w-4 h-4" />
                  <div>
                    <div>Assistant</div>
                    <div className="text-xs text-gray-500">Helpful, informative responses</div>
                  </div>
                </div>
              </SelectItem>
              <SelectItem value="rp">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  <div>
                    <div>Roleplay</div>
                    <div className="text-xs text-gray-500">Creative roleplay and storytelling</div>
                  </div>
                </div>
              </SelectItem>
              <SelectItem value="developer">
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4" />
                  <div>
                    <div>Developer</div>
                    <div className="text-xs text-gray-500">Technical programming assistance</div>
                  </div>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Voice Features */}
        <div className="space-y-3">
          <label className="text-sm font-medium text-red-700">Voice Features</label>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {settings.voiceToText ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              <span className="text-sm">Voice to Text</span>
            </div>
            <Switch
              checked={settings.voiceToText}
              onCheckedChange={(checked) => updateSetting("voiceToText", checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {settings.textToSpeech ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              <span className="text-sm">Text to Speech</span>
            </div>
            <Switch
              checked={settings.textToSpeech}
              onCheckedChange={(checked) => updateSetting("textToSpeech", checked)}
            />
          </div>
        </div>

        {/* Image Generation */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ImageIcon className="w-4 h-4" />
            <span className="text-sm">Image Generation</span>
          </div>
          <Switch
            checked={settings.imageGeneration}
            onCheckedChange={(checked) => updateSetting("imageGeneration", checked)}
          />
        </div>

        {/* Temperature */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-red-700">Creativity</label>
            <span className="text-xs text-gray-500">{settings.temperature}</span>
          </div>
          <Slider
            value={[settings.temperature]}
            onValueChange={(value) => updateSetting("temperature", value[0])}
            max={1}
            min={0}
            step={0.1}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-gray-500">
            <span>Focused</span>
            <span>Creative</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
