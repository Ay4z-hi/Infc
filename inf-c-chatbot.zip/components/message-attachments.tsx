"use client"

import { FileText, ImageIcon, Mic, Download } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface Attachment {
  type: "image" | "document" | "audio"
  name: string
  url: string
  size?: number
}

interface MessageAttachmentsProps {
  attachments: Attachment[]
}

export function MessageAttachments({ attachments }: MessageAttachmentsProps) {
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const downloadFile = (url: string, filename: string) => {
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  }

  return (
    <div className="space-y-2 mt-2">
      {attachments.map((attachment, index) => (
        <Card key={index} className="p-3">
          {attachment.type === "image" && (
            <div className="space-y-2">
              <img
                src={attachment.url || "/placeholder.svg"}
                alt={attachment.name}
                className="max-w-full max-h-64 rounded-lg object-cover"
              />
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" />
                  <span>{attachment.name}</span>
                  {attachment.size && <span className="text-gray-500">({formatFileSize(attachment.size)})</span>}
                </div>
                <Button variant="ghost" size="sm" onClick={() => downloadFile(attachment.url, attachment.name)}>
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}

          {attachment.type === "document" && (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                <div>
                  <p className="font-medium">{attachment.name}</p>
                  {attachment.size && <p className="text-sm text-gray-500">{formatFileSize(attachment.size)}</p>}
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => downloadFile(attachment.url, attachment.name)}>
                <Download className="w-4 h-4" />
              </Button>
            </div>
          )}

          {attachment.type === "audio" && (
            <div className="space-y-2">
              <audio controls className="w-full">
                <source src={attachment.url} type="audio/wav" />
                Your browser does not support the audio element.
              </audio>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <Mic className="w-4 h-4" />
                  <span>{attachment.name}</span>
                  {attachment.size && <span className="text-gray-500">({formatFileSize(attachment.size)})</span>}
                </div>
                <Button variant="ghost" size="sm" onClick={() => downloadFile(attachment.url, attachment.name)}>
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </Card>
      ))}
    </div>
  )
}
