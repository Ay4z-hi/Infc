"use client"

import type { ReactNode } from "react"

interface MarkdownRendererProps {
  content: string
  className?: string
}

export function MarkdownRenderer({ content, className = "" }: MarkdownRendererProps) {
  // Simple markdown parsing for basic formatting
  const parseMarkdown = (text: string): ReactNode[] => {
    const lines = text.split("\n")
    const elements: ReactNode[] = []
    let key = 0

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]

      // Headers
      if (line.startsWith("### ")) {
        elements.push(
          <h3 key={key++} className="text-lg font-semibold mt-4 mb-2">
            {line.substring(4)}
          </h3>,
        )
      } else if (line.startsWith("## ")) {
        elements.push(
          <h2 key={key++} className="text-xl font-semibold mt-4 mb-2">
            {line.substring(3)}
          </h2>,
        )
      } else if (line.startsWith("# ")) {
        elements.push(
          <h1 key={key++} className="text-2xl font-bold mt-4 mb-2">
            {line.substring(2)}
          </h1>,
        )
      }
      // Lists
      else if (line.startsWith("- ") || line.startsWith("• ")) {
        const listItems = [line]
        // Collect consecutive list items
        while (i + 1 < lines.length && (lines[i + 1].startsWith("- ") || lines[i + 1].startsWith("• "))) {
          i++
          listItems.push(lines[i])
        }
        elements.push(
          <ul key={key++} className="list-disc list-inside my-2 space-y-1">
            {listItems.map((item, idx) => (
              <li key={idx}>{item.substring(2)}</li>
            ))}
          </ul>,
        )
      }
      // Numbered lists
      else if (/^\d+\.\s/.test(line)) {
        const listItems = [line]
        // Collect consecutive numbered items
        while (i + 1 < lines.length && /^\d+\.\s/.test(lines[i + 1])) {
          i++
          listItems.push(lines[i])
        }
        elements.push(
          <ol key={key++} className="list-decimal list-inside my-2 space-y-1">
            {listItems.map((item, idx) => (
              <li key={idx}>{item.replace(/^\d+\.\s/, "")}</li>
            ))}
          </ol>,
        )
      }
      // Code blocks (handled separately)
      else if (line.startsWith("```")) {
        // Skip code blocks as they're handled by CodeCanvas
        while (i + 1 < lines.length && !lines[i + 1].startsWith("```")) {
          i++
        }
        i++ // Skip closing ```
      }
      // Regular paragraphs
      else if (line.trim()) {
        // Handle inline formatting
        let formattedLine = line

        // Bold text
        formattedLine = formattedLine.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")

        // Italic text
        formattedLine = formattedLine.replace(/\*(.*?)\*/g, "<em>$1</em>")

        // Inline code
        formattedLine = formattedLine.replace(
          /`(.*?)`/g,
          '<code class="bg-gray-200 dark:bg-gray-700 px-1 rounded text-sm">$1</code>',
        )

        elements.push(<p key={key++} className="mb-2" dangerouslySetInnerHTML={{ __html: formattedLine }} />)
      }
      // Empty lines
      else {
        elements.push(<br key={key++} />)
      }
    }

    return elements
  }

  return <div className={`prose prose-sm max-w-none ${className}`}>{parseMarkdown(content)}</div>
}
