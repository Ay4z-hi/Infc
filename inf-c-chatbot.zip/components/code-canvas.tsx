"use client"

import { useState } from "react"
import { Copy, Check, Download, Maximize2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface CodeCanvasProps {
  code: string
  language?: string
  filename?: string
}

export function CodeCanvas({ code, language = "javascript", filename }: CodeCanvasProps) {
  const [copied, setCopied] = useState(false)
  const [expanded, setExpanded] = useState(false)

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error("Failed to copy code:", error)
    }
  }

  const downloadCode = () => {
    const blob = new Blob([code], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename || `code.${getFileExtension(language)}`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getFileExtension = (lang: string) => {
    const extensions: { [key: string]: string } = {
      javascript: "js",
      typescript: "ts",
      python: "py",
      java: "java",
      cpp: "cpp",
      c: "c",
      html: "html",
      css: "css",
      json: "json",
      xml: "xml",
      sql: "sql",
      bash: "sh",
      shell: "sh",
    }
    return extensions[lang] || "txt"
  }

  const highlightCode = (code: string, language: string) => {
    // Simple syntax highlighting - in a real app, you'd use Prism.js or similar
    const keywords: { [key: string]: string[] } = {
      javascript: [
        "function",
        "const",
        "let",
        "var",
        "if",
        "else",
        "for",
        "while",
        "return",
        "class",
        "import",
        "export",
      ],
      python: ["def", "class", "if", "else", "elif", "for", "while", "return", "import", "from", "try", "except"],
      java: ["public", "private", "class", "interface", "if", "else", "for", "while", "return", "import", "package"],
    }

    let highlightedCode = code
    const langKeywords = keywords[language] || []

    langKeywords.forEach((keyword) => {
      const regex = new RegExp(`\\b${keyword}\\b`, "g")
      highlightedCode = highlightedCode.replace(regex, `<span class="text-blue-600 font-semibold">${keyword}</span>`)
    })

    // Highlight strings
    highlightedCode = highlightedCode.replace(
      /(["'`])((?:(?!\1)[^\\]|\\.)*)(\1)/g,
      '<span class="text-green-600">$1$2$3</span>',
    )

    // Highlight comments
    highlightedCode = highlightedCode.replace(
      /(\/\/.*$|\/\*[\s\S]*?\*\/|#.*$)/gm,
      '<span class="text-gray-500 italic">$1</span>',
    )

    return highlightedCode
  }

  return (
    <Card className={`overflow-hidden ${expanded ? "fixed inset-4 z-50" : "max-w-full"}`}>
      <div className="flex items-center justify-between p-3 bg-gray-100 dark:bg-gray-800 border-b">
        <div className="flex items-center gap-2">
          <div className="flex gap-1">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
          </div>
          {filename && <span className="text-sm font-medium">{filename}</span>}
          <span className="text-xs text-gray-500 bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded">{language}</span>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)}>
            <Maximize2 className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={downloadCode}>
            <Download className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={copyToClipboard}>
            {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>
      </div>
      <div className={`overflow-auto ${expanded ? "max-h-[calc(100vh-8rem)]" : "max-h-96"}`}>
        <pre className="p-4 text-sm font-mono leading-relaxed">
          <code
            dangerouslySetInnerHTML={{
              __html: highlightCode(code, language),
            }}
          />
        </pre>
      </div>
      {expanded && (
        <div className="absolute top-2 right-2">
          <Button variant="ghost" size="sm" onClick={() => setExpanded(false)}>
            ×
          </Button>
        </div>
      )}
    </Card>
  )
}
