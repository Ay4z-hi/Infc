"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Send, Bot, User, Plus, Menu, Settings, HelpCircle, ArrowLeft, Moon, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { SettingsModal } from "@/components/settings-modal"
import { FileUpload } from "@/components/file-upload"
import { VoiceRecorder } from "@/components/voice-recorder"
import { CodeCanvas } from "@/components/code-canvas"
import { MessageAttachments } from "@/components/message-attachments"
import { ImageGenerator } from "@/components/image-generator"
import { StreamingText } from "@/components/streaming-text"
import { MarkdownRenderer } from "@/components/markdown-renderer"
import { LandingPage } from "@/components/landing-page"
import { ModelSelector } from "@/components/model-selector"
import { ChatHistory } from "@/components/chat-history"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { DEFAULT_SETTINGS, type ChatSettings } from "@/types/models"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  attachments?: Array<{
    type: "image" | "document" | "audio"
    name: string
    url: string
    size?: number
  }>
  codeBlocks?: Array<{
    language: string
    code: string
    filename?: string
  }>
  transcript?: string
  imageUrl?: string
  imagePrompt?: string
  type?: "text" | "image"
  streaming?: boolean
  isComplete?: boolean
  model?: string
}

interface ChatSession {
  id: string
  title: string
  timestamp: Date
  messageCount: number
  preview: string
  messages: Message[]
}

export default function ChatPage() {
  // All hooks must be called before any conditional rendering
  const [showLanding, setShowLanding] = useState(true)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [isDarkMode, setIsDarkMode] = useLocalStorage("inf-c-dark-mode", false)
  const [chatSettings, setChatSettings] = useLocalStorage<ChatSettings>("inf-c-chat-settings", DEFAULT_SETTINGS)
  const [chatSessions, setChatSessions] = useLocalStorage<ChatSession[]>("inf-c-chat-sessions", [])
  const [currentSessionId, setCurrentSessionId] = useLocalStorage<string | null>("inf-c-current-session", null)
  const [modelSelectorOpen, setModelSelectorOpen] = useState(false)
  const [showChatHistory, setShowChatHistory] = useState(false)

  const [touchStart, setTouchStart] = useState<number | null>(null)
  const [touchEnd, setTouchEnd] = useState<number | null>(null)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Hello! I'm **Inf.C**, your advanced AI assistant created by **U.I.D.** (United Infernal Dominions). How can I help you today?\n\n💡 **Tip**: Start your message with `:ig:` to generate images!\n\n### What I can do:\n- Answer questions and provide information\n- Help with coding and technical tasks\n- Generate images with AI\n- Process files and documents\n- Voice-to-text transcription",
      streaming: false,
      isComplete: true,
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showTyping, setShowTyping] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [fontSize, setFontSize] = useState(14)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [animationsEnabled, setAnimationsEnabled] = useState(true)
  const [streamingSpeed, setStreamingSpeed] = useState(30)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [currentAttachments, setCurrentAttachments] = useState<
    Array<{
      type: "image" | "document" | "audio"
      name: string
      url: string
      size?: number
    }>
  >([])

  // Get current session
  const currentSession = chatSessions.find((s) => s.id === currentSessionId)

  // Load messages from current session
  useEffect(() => {
    if (currentSession) {
      setMessages(currentSession.messages)
    }
  }, [currentSession])

  // Save messages to current session
  useEffect(() => {
    if (currentSessionId && messages.length > 1) {
      setChatSessions((prev) =>
        prev.map((session) =>
          session.id === currentSessionId
            ? {
                ...session,
                messages,
                messageCount: messages.length,
                preview: messages[messages.length - 1]?.content?.substring(0, 100) || "",
                timestamp: new Date(),
              }
            : session,
        ),
      )
    }
  }, [messages, currentSessionId, setChatSessions])

  // Create new session
  const createNewSession = () => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: "New Conversation",
      timestamp: new Date(),
      messageCount: 1,
      preview: "Hello! I'm Inf.C...",
      messages: [
        {
          id: "1",
          role: "assistant",
          content:
            "Hello! I'm **Inf.C**, your advanced AI assistant created by **U.I.D.** (United Infernal Dominions). How can I help you today?\n\n💡 **Tip**: Start your message with `:ig:` to generate images!\n\n### What I can do:\n- Answer questions and provide information\n- Help with coding and technical tasks\n- Generate images with AI\n- Process files and documents\n- Voice-to-text transcription",
          streaming: false,
          isComplete: true,
        },
      ],
    }

    setChatSessions((prev) => [newSession, ...prev])
    setCurrentSessionId(newSession.id)
    setMessages(newSession.messages)
  }

  // All useEffect hooks
  useEffect(() => {
    if (!showLanding) {
      scrollToBottom()
    }
  }, [messages, showTyping, showLanding])

  useEffect(() => {
    // Apply theme
    const root = document.documentElement
    if (isDarkMode) {
      root.classList.add("dark")
      root.style.setProperty("--background", "linear-gradient(135deg, #1f2937 0%, #374151 100%)")
      root.style.setProperty("--card", "linear-gradient(135deg, #374151 0%, #4b5563 100%)")
    } else {
      root.classList.remove("dark")
      root.style.setProperty("--primary", "#dc2626")
      root.style.setProperty("--primary-foreground", "#ffffff")
      root.style.setProperty("--secondary", "#f97316")
      root.style.setProperty("--accent", "#fbbf24")
      root.style.setProperty("--background", "linear-gradient(135deg, #fef2f2 0%, #fef3c7 100%)")
      root.style.setProperty("--card", "linear-gradient(135deg, #fef2f2 0%, #fff7ed 100%)")
      root.style.setProperty("--muted", "#fed7d7")
    }
  }, [isDarkMode])

  // Initialize session if none exists
  useEffect(() => {
    if (!currentSessionId && chatSessions.length === 0) {
      createNewSession()
    }
  }, [currentSessionId, chatSessions.length])

  // All function definitions
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const minSwipeDistance = 50

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null)
    setTouchStart(e.targetTouches[0].clientX)
  }

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return

    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > -minSwipeDistance
    const isRightSwipe = distance > minSwipeDistance

    if (isLeftSwipe) {
      setSidebarOpen(false)
    }
    if (isRightSwipe) {
      setSidebarOpen(true)
    }
  }

  const handleFileSelect = (file: File, type: "image" | "document") => {
    const url = URL.createObjectURL(file)
    const attachment = {
      type,
      name: file.name,
      url,
      size: file.size,
    }
    setCurrentAttachments((prev) => [...prev, attachment])
  }

  const handleVoiceRecording = (audioBlob: Blob, transcript?: string) => {
    const url = URL.createObjectURL(audioBlob)
    const attachment = {
      type: "audio" as const,
      name: `voice-${Date.now()}.wav`,
      url,
      size: audioBlob.size,
    }
    setCurrentAttachments((prev) => [...prev, attachment])

    if (transcript) {
      setInput((prev) => prev + (prev ? " " : "") + transcript)
    }
  }

  const handleTranscriptOnly = (transcript: string) => {
    setInput((prev) => prev + (prev ? " " : "") + transcript)
  }

  const addImageGenerationExample = () => {
    setInput(":ig: a majestic dragon breathing fire in a fantasy landscape with glowing crystals")
  }

  const handleStreamingComplete = (messageId: string) => {
    setMessages((prev) =>
      prev.map((msg) => (msg.id === messageId ? { ...msg, isComplete: true, streaming: false } : msg)),
    )
  }

  const sendMessage = async () => {
    const text = input.trim()
    if (!text && currentAttachments.length === 0) return
    if (isLoading) return

    // Create session if none exists
    if (!currentSessionId) {
      createNewSession()
    }

    const isImageGeneration = text.startsWith(":ig:")

    setInput("")
    const messageWithAttachments = {
      id: Date.now().toString(),
      role: "user" as const,
      content: text || "Shared files",
      attachments: currentAttachments.length > 0 ? [...currentAttachments] : undefined,
      isComplete: true,
    }

    setMessages((prev) => [...prev, messageWithAttachments])
    const attachmentsToSend = [...currentAttachments]
    setCurrentAttachments([])
    setIsLoading(true)
    setShowTyping(true)

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, { role: "user", content: text }],
          attachments: attachmentsToSend,
          settings: chatSettings,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.error("HTTP Error:", response.status, errorText)
        throw new Error(`HTTP ${response.status}: ${errorText}`)
      }

      const responseText = await response.text()

      if (!responseText.trim()) {
        throw new Error("Empty response from server")
      }

      let data
      try {
        data = JSON.parse(responseText)
      } catch (parseError) {
        console.error("JSON Parse Error:", parseError)
        throw new Error("Invalid response format from server")
      }

      setShowTyping(false)

      if (typeof data === "object" && data.type === "image") {
        // Handle image generation response
        const assistantMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: data.text,
          type: "image",
          imageUrl: data.imageUrl,
          imagePrompt: data.prompt,
          streaming: data.streaming || false,
          isComplete: !data.streaming,
          model: chatSettings.model,
        }
        setMessages((prev) => [...prev, assistantMessage])
      } else {
        // Handle regular chat response with streaming
        const reply = typeof data === "string" ? data : data.text || "Sorry, I couldn't process that."
        const codeBlocks = typeof data === "object" ? data.codeBlocks : undefined
        const shouldStream = data.streaming !== false

        const assistantMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: reply,
          codeBlocks,
          streaming: shouldStream,
          isComplete: !shouldStream,
          model: data.model || chatSettings.model,
        }
        setMessages((prev) => [...prev, assistantMessage])
      }

      if (soundEnabled) {
        const audio = new Audio(
          "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmHgU7k9n1unEiBC13yO/eizEIHWq+8+OWT",
        )
        audio.play().catch(() => {})
      }
    } catch (error) {
      setShowTyping(false)
      console.error("Send message error:", error)

      let errorMessage = "I'm having trouble connecting right now. "

      if (error instanceof Error) {
        if (error.message.includes("JSON")) {
          errorMessage += "There seems to be a communication issue with the server."
        } else if (error.message.includes("HTTP")) {
          errorMessage += "The server returned an error response."
        } else if (error.message.includes("Empty")) {
          errorMessage += "The server didn't respond properly."
        } else {
          errorMessage += error.message
        }
      } else {
        errorMessage += "Please check your connection and try again."
      }

      const errorMessageObj: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: errorMessage + "\n\n💡 Try refreshing the page or checking your internet connection.",
        isComplete: true,
      }

      setMessages((prev) => [...prev, errorMessageObj])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const TypingIndicator = () => (
    <div className="flex items-start space-x-3">
      <Avatar className="w-8 h-8 bg-gradient-to-r from-red-500 to-orange-500">
        <AvatarFallback>
          <Bot className="w-4 h-4 text-white" />
        </AvatarFallback>
      </Avatar>
      <div className="bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-2xl px-4 py-3">
        <div className="flex space-x-1">
          <div className="w-2 h-2 bg-red-400 rounded-full animate-bounce"></div>
          <div className="w-2 h-2 bg-red-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
          <div className="w-2 h-2 bg-red-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
        </div>
      </div>
    </div>
  )

  // Conditional rendering handled in JSX return, not early return
  return (
    <div
      className="flex h-screen w-full overflow-hidden"
      style={{
        fontSize: `${fontSize}px`,
        background: "var(--background, linear-gradient(135deg, #fef2f2 0%, #fef3c7 100%))",
      }}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {showLanding ? (
        <LandingPage onEnterChat={() => setShowLanding(false)} />
      ) : (
        <>
          {/* Mobile Sidebar Overlay */}
          {sidebarOpen && (
            <div className="fixed inset-0 bg-black/50 z-20 lg:hidden" onClick={() => setSidebarOpen(false)} />
          )}

          {/* Sidebar */}
          <div
            className={`${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 fixed lg:relative z-30 w-64 sm:w-72 lg:w-80 bg-gradient-to-b from-red-50 to-orange-50 dark:from-gray-800 dark:to-gray-900 border-r border-red-200 dark:border-gray-700 flex flex-col transition-transform duration-300 ease-in-out h-full`}
          >
            {/* Header */}
            <div className="p-4 border-b border-red-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h1 className="font-semibold text-red-800 dark:text-red-200">Inf.C</h1>
                    <p className="text-xs text-red-600 dark:text-red-400">by U.I.D.</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsDarkMode(!isDarkMode)}
                    className="text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-gray-700"
                  >
                    {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowLanding(true)}
                    className="lg:hidden text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-gray-700"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* New Chat Button */}
            <div className="p-4">
              <Button
                className="w-full justify-start bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white"
                onClick={createNewSession}
              >
                <Plus className="w-4 h-4 mr-2" />
                New Chat
              </Button>
            </div>

            {/* Chat History */}
            <div className="flex-1 px-4">
              <ChatHistory
                sessions={chatSessions}
                currentSessionId={currentSessionId}
                onSelectSession={setCurrentSessionId}
                onDeleteSession={(sessionId) => {
                  setChatSessions((prev) => prev.filter((s) => s.id !== sessionId))
                  if (currentSessionId === sessionId) {
                    setCurrentSessionId(null)
                    createNewSession()
                  }
                }}
                onNewSession={createNewSession}
              />
            </div>

            {/* Bottom Actions */}
            <div className="p-4 border-t border-red-200 dark:border-gray-700 space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-gray-700"
                size="sm"
                onClick={() => setSettingsOpen(true)}
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-gray-700"
                size="sm"
              >
                <HelpCircle className="w-4 h-4 mr-2" />
                Help & FAQ
              </Button>
            </div>
          </div>

          {/* Main Chat Area */}
          <div className="flex-1 flex flex-col min-w-0">
            {/* Top Bar */}
            <div className="bg-gradient-to-r from-red-50 to-orange-50 dark:from-gray-800 dark:to-gray-700 border-b border-red-200 dark:border-gray-700 p-3 sm:p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3 min-w-0">
                  <Button variant="ghost" size="sm" className="lg:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
                    <Menu className="w-4 h-4" />
                  </Button>
                  <div className="min-w-0">
                    <h2 className="font-semibold text-red-800 dark:text-red-200 truncate">Inf.C Assistant</h2>
                    <p className="text-sm text-red-600 dark:text-red-400 truncate">
                      {isLoading
                        ? input.startsWith(":ig:")
                          ? "Generating image..."
                          : "Thinking..."
                        : `${chatSettings.model.split("/").pop()?.split(":")[0]} • ${chatSettings.mode} mode`}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2 relative">
                  <ModelSelector
                    settings={chatSettings}
                    onSettingsChange={setChatSettings}
                    isOpen={modelSelectorOpen}
                    onToggle={() => setModelSelectorOpen(!modelSelectorOpen)}
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSettingsOpen(true)}
                    className="text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-gray-700"
                  >
                    <Settings className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Messages Area */}
            <ScrollArea
              className="flex-1 p-3 sm:p-4"
              style={{ background: "var(--background, linear-gradient(135deg, #fef2f2 0%, #fef3c7 100%))" }}
            >
              <div className="max-w-4xl mx-auto space-y-4 sm:space-y-6">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex items-start space-x-2 sm:space-x-3 ${
                      message.role === "user" ? "justify-end" : "justify-start"
                    } ${animationsEnabled ? "animate-in fade-in-0 slide-in-from-bottom-2" : ""}`}
                  >
                    {message.role === "assistant" && (
                      <Avatar className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-red-500 to-orange-500 flex-shrink-0">
                        <AvatarFallback>
                          <Bot className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                        </AvatarFallback>
                      </Avatar>
                    )}

                    <div
                      className={`max-w-[85%] sm:max-w-3xl rounded-2xl px-3 py-2 sm:px-4 sm:py-3 ${
                        message.role === "user"
                          ? "bg-gradient-to-r from-red-500 to-orange-500 text-white"
                          : "bg-gradient-to-r from-red-50 to-orange-50 dark:from-gray-700 dark:to-gray-600 border border-red-200 dark:border-gray-600 text-red-900 dark:text-gray-100"
                      }`}
                    >
                      {message.role === "assistant" && message.streaming && !message.isComplete ? (
                        <StreamingText
                          text={message.content}
                          speed={streamingSpeed}
                          onComplete={() => handleStreamingComplete(message.id)}
                          className="prose prose-sm max-w-none dark:prose-invert"
                        />
                      ) : message.role === "assistant" ? (
                        <MarkdownRenderer
                          content={message.content}
                          className="prose prose-sm max-w-none dark:prose-invert"
                        />
                      ) : (
                        <div className="prose prose-sm max-w-none whitespace-pre-wrap break-words">
                          {message.content}
                        </div>
                      )}

                      {message.transcript && (
                        <div className="mt-2 text-xs opacity-75 italic">Transcript: "{message.transcript}"</div>
                      )}

                      {message.attachments && <MessageAttachments attachments={message.attachments} />}

                      {message.imageUrl && message.imagePrompt && (
                        <ImageGenerator imageUrl={message.imageUrl} prompt={message.imagePrompt} />
                      )}

                      {message.codeBlocks &&
                        message.codeBlocks.map((block, index) => (
                          <div key={index} className="mt-3">
                            <CodeCanvas code={block.code} language={block.language} filename={block.filename} />
                          </div>
                        ))}

                      {message.model && message.role === "assistant" && (
                        <div className="mt-2 text-xs opacity-60">
                          Generated by {message.model.split("/").pop()?.split(":")[0]}
                        </div>
                      )}
                    </div>

                    {message.role === "user" && (
                      <Avatar className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-orange-400 to-red-400 flex-shrink-0">
                        <AvatarFallback>
                          <User className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                ))}

                {showTyping && <TypingIndicator />}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Input Area */}
            <div className="bg-gradient-to-r from-red-50 to-orange-50 dark:from-gray-800 dark:to-gray-700 border-t border-red-200 dark:border-gray-700 p-3 sm:p-4">
              <div className="max-w-4xl mx-auto">
                {/* Show current attachments */}
                {currentAttachments.length > 0 && (
                  <div className="mb-3">
                    <MessageAttachments attachments={currentAttachments} />
                  </div>
                )}

                <div className="flex items-end space-x-2 sm:space-x-3">
                  <div className="flex items-center gap-1 sm:gap-2">
                    <FileUpload onFileSelect={handleFileSelect} disabled={isLoading} />
                    {chatSettings.voiceToText && (
                      <VoiceRecorder
                        onRecordingComplete={handleVoiceRecording}
                        onTranscriptOnly={handleTranscriptOnly}
                        disabled={isLoading}
                      />
                    )}
                  </div>

                  <div className="flex-1 relative min-w-0">
                    <Input
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder={
                        chatSettings.imageGeneration ? "Message Inf.C... (Use :ig: for images)" : "Message Inf.C..."
                      }
                      className="pr-12 py-2 sm:py-3 rounded-2xl border-red-300 dark:border-gray-600 bg-gradient-to-r from-red-50 to-orange-50 dark:from-gray-700 dark:to-gray-600 focus:border-red-500 focus:ring-red-500 text-red-900 dark:text-gray-100 placeholder-red-500 dark:placeholder-gray-400 text-sm sm:text-base"
                      disabled={isLoading}
                    />
                    <Button
                      onClick={sendMessage}
                      size="sm"
                      disabled={(!input.trim() && currentAttachments.length === 0) || isLoading}
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 rounded-xl bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 disabled:bg-gray-300 p-2"
                    >
                      <Send className="w-3 h-3 sm:w-4 sm:h-4" />
                    </Button>
                  </div>
                </div>
                <p className="text-xs text-red-600 dark:text-red-400 mt-2 text-center px-2">
                  Inf.C can make mistakes. Consider checking important information. • Using{" "}
                  {chatSettings.model.split("/").pop()?.split(":")[0]} in {chatSettings.mode} mode
                </p>
              </div>
            </div>
          </div>

          {/* Settings Modal */}
          <SettingsModal
            isOpen={settingsOpen}
            onClose={() => setSettingsOpen(false)}
            theme={isDarkMode ? "dark" : "fiery"}
            onThemeChange={(theme) => setIsDarkMode(theme === "dark")}
            fontSize={fontSize}
            onFontSizeChange={setFontSize}
            soundEnabled={soundEnabled}
            onSoundToggle={setSoundEnabled}
            animationsEnabled={animationsEnabled}
            onAnimationsToggle={setAnimationsEnabled}
          />
        </>
      )}
    </div>
  )
}
