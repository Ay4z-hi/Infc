export async function POST(req: Request) {
  const { prompt } = await req.json()

  const API_KEY = "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"

  // List of free image models to try in order of preference
  const imageModels = [
    "black-forest-labs/flux-1-schnell:free",
    "stabilityai/stable-diffusion-xl-base-1.0:free",
    "runwayml/stable-diffusion-v1-5:free",
    "CompVis/stable-diffusion-v1-4:free",
  ]

  for (const model of imageModels) {
    try {
      console.log(`Trying image model: ${model}`)

      const response = await fetch("https://openrouter.ai/api/v1/images/generations", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: model,
          prompt: prompt,
          n: 1,
          size: "1024x1024",
          response_format: "url",
        }),
      })

      const data = await response.json()

      if (data.error) {
        console.error(`Error with model ${model}:`, data.error)
        continue // Try next model
      }

      const imageUrl = data?.data?.[0]?.url

      if (imageUrl) {
        return new Response(
          JSON.stringify({
            success: true,
            imageUrl: imageUrl,
            model: model,
            prompt: prompt,
          }),
          {
            headers: { "Content-Type": "application/json" },
          },
        )
      }
    } catch (error) {
      console.error(`Failed to generate image with model ${model}:`, error)
      continue // Try next model
    }
  }

  // If all models fail, return error
  return new Response(
    JSON.stringify({
      success: false,
      error: "All image generation models are currently unavailable. Please try again later.",
    }),
    {
      status: 500,
      headers: { "Content-Type": "application/json" },
    },
  )
}
