export async function POST(req: Request) {
  const { messages, attachments, settings } = await req.json()

  const API_KEY = "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"

  // Use the selected model from settings, fallback to default
  const CHAT_MODEL = settings?.model || "meta-llama/llama-3-70b-instruct:free"

  try {
    // Get the last user message to check for image generation
    const lastMessage = messages[messages.length - 1]
    const isImageGeneration = lastMessage?.content?.startsWith(":ig:")

    if (isImageGeneration && settings?.imageGeneration) {
      // Extract the image prompt (remove :ig: prefix)
      const imagePrompt = lastMessage.content.substring(4).trim()

      if (!imagePrompt) {
        return new Response(JSON.stringify("Please provide a description after :ig: to generate an image."), {
          status: 400,
          headers: { "Content-Type": "application/json" },
        })
      }

      // Use Gemini for image generation if available, otherwise fallback
      const imageModel =
        settings?.model === "google/gemini-2.5-pro" ? "google/gemini-2.5-pro" : "black-forest-labs/flux-1-schnell:free"

      try {
        // Try Pollinations first (most reliable free option)
        const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(imagePrompt)}?width=1024&height=1024&seed=${Math.floor(Math.random() * 1000000)}&model=flux&nologo=true`

        // Test if the image URL is accessible
        const testResponse = await fetch(pollinationsUrl, { method: "HEAD" })

        if (testResponse.ok) {
          return new Response(
            JSON.stringify({
              type: "image",
              imageUrl: pollinationsUrl,
              prompt: imagePrompt,
              text: `🎨 I've generated an image for: "${imagePrompt}"\n\n*Generated using Pollinations AI with FLUX model*`,
              service: "Pollinations",
            }),
            {
              headers: { "Content-Type": "application/json" },
            },
          )
        }
      } catch (error) {
        console.log("Pollinations failed, trying OpenRouter...")
      }

      // Fallback to OpenRouter image generation
      try {
        const response = await fetch("https://openrouter.ai/api/v1/images/generations", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${API_KEY}`,
            "Content-Type": "application/json",
            "HTTP-Referer": "https://inf-c.vercel.app",
            "X-Title": "Inf.C Chatbot",
          },
          body: JSON.stringify({
            model: imageModel,
            prompt: imagePrompt,
            n: 1,
            size: "1024x1024",
            response_format: "url",
          }),
        })

        if (response.ok) {
          const data = await response.json()
          const imageUrl = data?.data?.[0]?.url

          if (imageUrl) {
            return new Response(
              JSON.stringify({
                type: "image",
                imageUrl: imageUrl,
                prompt: imagePrompt,
                text: `🎨 I've generated an image for: "${imagePrompt}"\n\n*Generated using ${imageModel}*`,
                service: "OpenRouter",
              }),
              {
                headers: { "Content-Type": "application/json" },
              },
            )
          }
        }
      } catch (error) {
        console.log("OpenRouter image generation failed:", error)
      }

      // Final fallback
      const fallbackUrl = `https://picsum.photos/1024/1024?random=${Math.floor(Math.random() * 1000)}`
      return new Response(
        JSON.stringify({
          type: "image",
          imageUrl: fallbackUrl,
          prompt: imagePrompt,
          text: `🎨 Here's a placeholder image while we work on AI generation for: "${imagePrompt}"\n\n*Using fallback service*`,
          service: "Fallback",
        }),
        {
          headers: { "Content-Type": "application/json" },
        },
      )
    }

    // Regular chat processing with streaming
    let systemMessage = `You are Inf.C, an advanced AI assistant created by U.I.D. (United Infernal Dominions), developed by ay4z. 

U.I.D. Leadership:
- President: ay4z (Safwan Ayaz)
- Vice Presidents: a_ravnn (S.M. Shayan Sadid) and User 39430

Current Model: ${CHAT_MODEL}
Mode: ${settings?.mode || "assistant"}

`

    // Adjust system message based on mode
    switch (settings?.mode) {
      case "rp":
        systemMessage += `You are in roleplay mode. Be creative, engaging, and immersive in your responses. Adapt to different characters and scenarios as requested. Use descriptive language and maintain character consistency.`
        break
      case "developer":
        systemMessage += `You are in developer mode. Focus on providing technical assistance, code examples, debugging help, and detailed explanations of programming concepts. Be precise and include relevant code snippets when helpful.`
        break
      default:
        systemMessage += `You are helpful, intelligent, and represent the cutting-edge technology of U.I.D. Be professional, knowledgeable, and assist users with any questions or tasks.`
    }

    systemMessage += `

For image generation, users can start their message with ":ig:" followed by their image description.

Write in a conversational, helpful tone. Use markdown formatting when appropriate for better readability.`

    // Enhanced message processing for attachments
    const enhancedMessages = [...messages]

    if (attachments && attachments.length > 0) {
      systemMessage += "\n\nThe user has shared files with you. Analyze their content and respond appropriately."

      // Add attachment information to the last user message
      const lastMessage = enhancedMessages[enhancedMessages.length - 1]
      if (lastMessage && lastMessage.role === "user") {
        let attachmentInfo = "\n\nAttached files:\n"
        attachments.forEach((attachment: any, index: number) => {
          attachmentInfo += `${index + 1}. ${attachment.name} (${attachment.type})\n`
        })
        lastMessage.content += attachmentInfo
      }
    }

    console.log("Making request to OpenRouter API with model:", CHAT_MODEL)

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://inf-c.vercel.app",
        "X-Title": "Inf.C Chatbot",
      },
      body: JSON.stringify({
        model: CHAT_MODEL,
        messages: [
          {
            role: "system",
            content: systemMessage,
          },
          ...enhancedMessages,
        ],
        max_tokens: 2000,
        temperature: settings?.temperature || 0.7,
        stream: false,
      }),
    })

    console.log("Response status:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error("API Error Response:", errorText)

      let errorMessage = "API request failed"
      try {
        const errorData = JSON.parse(errorText)
        errorMessage = errorData.error?.message || errorData.message || errorMessage
      } catch {
        errorMessage = errorText || errorMessage
      }

      return new Response(
        JSON.stringify(`Sorry, I'm having trouble connecting to my AI service right now. Error: ${errorMessage}`),
        {
          status: 500,
          headers: { "Content-Type": "application/json" },
        },
      )
    }

    const responseText = await response.text()

    if (!responseText.trim()) {
      throw new Error("Empty response from API")
    }

    let data
    try {
      data = JSON.parse(responseText)
    } catch (parseError) {
      console.error("JSON Parse Error:", parseError)
      throw new Error("Invalid JSON response from API")
    }

    const reply = data?.choices?.[0]?.message?.content

    if (!reply) {
      console.error("No content in API response:", data)
      throw new Error("No response content from API")
    }

    // Enhanced code detection and formatting
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g
    let match
    const codeBlocks = []

    while ((match = codeBlockRegex.exec(reply)) !== null) {
      codeBlocks.push({
        language: match[1] || "text",
        code: match[2].trim(),
        fullMatch: match[0],
      })
    }

    // Return response with streaming flag
    const responseData = {
      text: reply,
      codeBlocks: codeBlocks.length > 0 ? codeBlocks : undefined,
      streaming: true,
      model: CHAT_MODEL,
    }

    return new Response(JSON.stringify(responseData), {
      headers: {
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    console.error("API Error:", error)

    const fallbackResponse =
      "I apologize, but I'm experiencing technical difficulties right now. This could be due to:\n\n• Network connectivity issues\n• API service temporarily unavailable\n• Rate limiting\n\nPlease try again in a moment. If the problem persists, the service may be undergoing maintenance."

    return new Response(JSON.stringify({ text: fallbackResponse, streaming: true }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
      },
    })
  }
}
