export interface AIModel {
  id: string
  name: string
  provider: string
  description: string
  capabilities: string[]
  free: boolean
}

export interface ChatSettings {
  model: string
  mode: "assistant" | "rp" | "developer"
  voiceToText: boolean
  textToSpeech: boolean
  imageGeneration: boolean
  temperature: number
}

export const AI_MODELS: AIModel[] = [
  {
    id: "meta-llama/llama-3-70b-instruct:free",
    name: "LLaMA 3 70B",
    provider: "Meta",
    description: "Best overall performance for text generation, RP, and natural conversation",
    capabilities: ["text", "reasoning", "roleplay", "conversation"],
    free: true,
  },
  {
    id: "deepseek/deepseek-moe:16b",
    name: "DeepSeek MoE",
    provider: "DeepSeek",
    description: "Advanced reasoning, programming help, and AI explanations",
    capabilities: ["reasoning", "programming", "analysis", "explanations"],
    free: true,
  },
  {
    id: "google/gemini-2.5-pro",
    name: "Gemini 2.5 Pro",
    provider: "Google",
    description: "Multimodal tasks, image generation, and chart creation",
    capabilities: ["multimodal", "images", "charts", "analysis"],
    free: false,
  },
  {
    id: "openchat/openchat-7b:free",
    name: "OpenChat 7B",
    provider: "OpenChat",
    description: "Fast and efficient conversational AI",
    capabilities: ["conversation", "general"],
    free: true,
  },
]

export const DEFAULT_SETTINGS: ChatSettings = {
  model: "meta-llama/llama-3-70b-instruct:free",
  mode: "assistant",
  voiceToText: true,
  textToSpeech: false,
  imageGeneration: true,
  temperature: 0.7,
}
